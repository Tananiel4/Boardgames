export interface Filters {
  playerCount: number | null;
  category: string | null;
  minAge: number | null;
  searchQuery: string;
}
